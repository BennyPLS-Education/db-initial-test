package second;

public class ClassroomException extends Exception {

    public ClassroomException() {
        super();
    }

    public ClassroomException(String message) {
        super(message);
    }
}
