package first;

public class factura {
    public String device;
    public double price;
    public factura(String device, double price) {
        this.device = device;
        this.price = price;
    }
}
